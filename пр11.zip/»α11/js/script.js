	let one_minute = 0,
		time_bar = 0;

	function slider( nav )
	{
	
		let get_slide,
			dots = $('.dots > span.active'),
			slider_count = $('.slider > div:not(.dots)').length;
		
		if ( typeof(nav) === 'object' )
			get_slide = nav.data('slide');
			
		else
			get_slide = ( nav == 'left' ) ? parseInt( dots.data('slide') ) - 1 : parseInt( dots.data('slide') ) + 1;

			
		if ( get_slide > slider_count )
			get_slide = 1;
			
		else if ( get_slide < 1 )
			get_slide = slider_count;
			
		
		dots.removeClass('active');
		$('.dots > span:nth-child(' + get_slide + ')').addClass('active');
			
		$('.slider > div.active').removeClass('active');
		$('.slider > div:nth-child(' + get_slide + ')').addClass('active');
		
		return;
	
	}
	
	function ads_timer()
	{
		
		let timer = setTimeout(function()
			{

				if ( one_minute == 60 )
				{
				
					clearTimeout('timer');
					
					$('#ads').remove();
					$('video').get(0).play();
					
					return;
				
				}
		
				$('#progressbar').progressbar( "option",
				{
					value: time_bar
				});

				time_bar = time_bar + 1.7;
				one_minute = one_minute + 1;

				ads_timer();

			}, 1000);
						
	}
	
	$(function()
	{
	
		let slider_count = $('.slider > div:not(.dots)').length;
		
		if ( slider_count != 0 )
		{
		
			let a,
				b = false,
				slide;
			
			$.each( $('.slider > div:not(.dots)'), function( index )
			{

				slide = parseInt(index) + 1;
				
				a = ( !b ) ? '<span data-slide="' + slide + '" class="active"></span>' : a + '<span data-slide="' + slide + '"></span>';
				
				b = true;
			
			});
			
			$('.slider').append( '<div class="dots">' + a + '</div>' );
		
		}
		
		$(document).on('keyup', function(e)
		{
			
			if ( e.which == 37 )
				slider('left');
				
			else if ( e.which == 39 )
				slider('right');
		
		});
		
		$(document).on('click', '.dots span', function()
		{

			slider( $(this) );
		
		});
	
		$(document).on('click', 'video', function(e)
		{

			( $(this).get(0).paused == true ) ? $(this).get(0).play() : $(this).get(0).pause();
			
			setTimeout(function()
			{
					
				$('video').get(0).pause();
					
				$('#videoss').append('<div id="ads"><div id="progressbar"></div></div>');
				
				$('#progressbar').progressbar(
				{
					value: false
				});
				
				ads_timer();
			
			}, 1000);
			
			console.log(e);
		
		});

	});
	
</script>